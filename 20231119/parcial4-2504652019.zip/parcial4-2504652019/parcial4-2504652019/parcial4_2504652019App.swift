//
//  parcial4_2504652019App.swift
//  parcial4-2504652019
//
//  Created by Rosa Herrera on 19/11/23.
//

import SwiftUI

@main
struct parcial4_2504652019App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

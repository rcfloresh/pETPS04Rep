//
//  operacionesApp.swift
//  operaciones
//
//  Created by Roberto Flores on 8/10/23.
//

import SwiftUI

@main
struct operacionesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
